/**Contants for server and fixed message */
app.constant('CONFIG', {
'HTTP_HOSTStaging':'http://silkyfusion.in/appNameWeb/stagging-v2/',
// 'HTTP_HOSTStaging':'http://localhost/appNameWeb/stagging-v2/',
"servererrmsg":"We cannot connect to our servers at this time, please check your network connection and try again",
"connerrmsg":"We cannot connect to our servers at this time, please check your network connection and try again",
"connecterr":"Connection Error",
"NTWORKTITLE": "Network Error",
"successtitle": "Success"
});
